//: Playground - noun: a place where people can play

import UIKit

//: 1. Hugh Scrooge tiene un crédito en MajorBusiness Bank que se compone de 320 de capital adeudado más el 12% de interés sobre dicho capital. El total de esta deuda deberá ser cancelada en 12 cuotas mensuales. Él Está considerando a PiggyBank Co. que tiene un nuevo producto de compra de cartera en donde traspasará el total de la deuda y sobre la misma un 9% de interés y que deberá pagar en 36 cuotas mensuales. Calcule ambas deudas y el valor de cada cuota mensual, con el fin de que Scrooge pueda decidir qué le conviene más para sus finanzas mensuales y sus pasivos.

let totalDebtMajorBusiness = 320 * 1.12
let majorBusinessFee = totalDebtMajorBusiness / 12

let totalDebtPiggyBank = totalDebtMajorBusiness * 1.09
let piggyBankFee = totalDebtPiggyBank / 36



//: 2. El transporte de bienes y valores YourMoney envía su transporte 135 a cubrir la ruta 44 e inicia en el primer punto recogiendo 900000. Luego en el segundo punto recoge 500000. En el tercer punto debe dejar 600000. En el cuarto punto recoge 470000. En el quinto y sexto punto deja 120000 y 240000 respectivamente. Finalmente recoge 340000 en el séptimo punto. Determine cuánto fue el total de recolecciones y con cuánto llegó al final del recorrido.

var yourMonkey135 = 0

var firstPoint = 900000
var secondPoint = 500000
var thirdPoint = 600000
var forthPoint = 470000
var fifthPoint = 120000
var sixthPoint = 240000
var seventhPoint = 340000

yourMonkey135 = firstPoint
yourMonkey135 = yourMonkey135 + secondPoint
yourMonkey135 = yourMonkey135 - thirdPoint
yourMonkey135 = yourMonkey135 + forthPoint
yourMonkey135 = yourMonkey135 - fifthPoint
yourMonkey135 = yourMonkey135 - sixthPoint
yourMonkey135 = yourMonkey135 + seventhPoint

let totalCollecting = firstPoint + secondPoint + forthPoint + seventhPoint


//: 3. Si tengo una deuda de 25000 con un interés del %0.9 mensual, ¿Cuánto deberé al quinto mes si no he abonado nada a mi capital?

let debt = 25000.0
let rate = 0.009

var totalDebt = debt + (debt * rate)  // Primer mes
totalDebt = totalDebt + (debt * rate)  // Segundo mes
totalDebt = totalDebt + (debt * rate)  // tercero mes
totalDebt = totalDebt + (debt * rate)  // cuarto mes
totalDebt = totalDebt + (debt * rate)  // quinto mes
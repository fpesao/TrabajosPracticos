//: Playground - noun: a place where people can play

import UIKit

var control = "Hola! Esta es una prueba"

let numberOfCharacters = control.characters.count
let isEven = numberOfCharacters % 2 == 0 ? true : false

let oddOrEven = isEven ? "par" : "impar"

let noCharacters = "El string no contiene caracteres, es vacío."
let oddOrEvenCharacters = "El string contiene una cantidad \(oddOrEven) de caracteres, porque tiene \(numberOfCharacters)"

var result = control.characters.count == 0 ? noCharacters : oddOrEvenCharacters

print(result)

var suffix = "prueba"
var prefix = "Hola"

result = control.hasSuffix(suffix) ? "El string termina con \(suffix)" : "El string no termina con \(suffix)"

print(result)

result = control.hasPrefix(prefix) ? "El string inicia con \(prefix)" : "El string no inicia con \(prefix)"

print(result)

let halfCount = numberOfCharacters / 2
let index = control.index(control.startIndex, offsetBy: halfCount)

let halfString = control.substring(to: index)

result = "La primera mitad del string es: \(halfString)"

print(result)



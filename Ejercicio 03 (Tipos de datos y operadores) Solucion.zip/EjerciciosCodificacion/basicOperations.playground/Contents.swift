//: Playground - noun: a place where people can play

import UIKit


//: 1. Dado un valor entregado en la constante entera value, identificar si dicho valor es par o impar

let value = 4

let reminder = value % 2
let isEven = reminder == 0

//: 2. Resolver el binomio cuadrado perfecto para los valores a = 5 y b = 3

let a = 5
let b = 3

// (a + b)^2 = a^2 + 2ab + b^2

let result = (a * a) + (2 * a * b) + (b * b)

//: 3. Hallar el área y perímetro de una circunferencia de diámetro 8.

// area = π (radius^2)
let pi = 3.141592
let radius = 8.0 / 2.0
let area = pi * (radius * radius)
let perimeter = 2.0 * pi * radius


//: 4. Se tienen 5 interruptores, todos apagados. Dado el cirtuito:
//: ((switch1 AND switch2) AND (switch1 OR switch3)) OR (NOT switch4 || (switch5 AND NOT switch3)) AND (switch2 OR switch1)
//: 4.1. Hallar la o las soluciones en donde el paso del circuito esté encendido, encendiendo uno, varios o todos los interruptores.
//: 4.2. Determinar cuál es el interruptor que si se enciende solo, no enciende el circuito.

let switch1 = false
let switch2 = false
let switch3 = true
let switch4 = false
let switch5 = false

let logicResult = ((switch1 && switch2) && (switch1 || switch3)) || (!(switch4) || (switch5 && !switch3)) && (switch2 || switch1)

// Solución. Encendiendo cualquier interruptor da como resultado el circuito encendido, excepto por el tercer interruptor.
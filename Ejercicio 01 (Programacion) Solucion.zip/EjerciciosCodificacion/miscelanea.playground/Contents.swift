//: Playground - noun: a place where people can play

import UIKit

//: 1. La compañía DuckCo necesita calcular nómina de su empleado, Hugh Scrooge, basado en la siguiente información:
//: Hugh trabajó durante 26 días, tres de los cuales fueron domingo. Además, durante algunos días trabajó horas extra nocturnas por un total de 12. Calcule el valor total que se le debe pagar a Scrooge teniendo en cuenta que cada día laboral es de 8 horas y que la horas normales de trabajo se pagan a 120, mientras que las nocturnas se pagan a 130 y las dominicales a 150.

23 * 8 //Total de horas normales trabajadas = 184
3 * 8 //Total de horas dominicales trabajadas = 24

(120 * 184) + (24 * 150) + (12 * 130)

//: Solución: El total devengado por Hugh Scrooge es de 27240.


//: 2. Durante el recorrido del autobús Ruta 134, en la estación de partida recoge 24 pasajeros. Luego en la estación Alegría se bajan 4 pasajeros y se suben 8. En la estación Bienestar debe seguir de largo pues se están haciendo reparaciones, así que en la siguiente estación, Cordialidad, deben bajarse 3 pasajeros de Bienestar más otros 5. Se suben 2 pasajeros. En la última estación, Destino, bajan los pasajeros restantes.
 //: Calcule cuántos pasajeros llegaron a Cordialidad y cuántos pasajeros en total viajaron en la ruta 134.

24 - 4 + 8   //Solución 1: 28 pasajeros llegaron a Cordialidad. Luego de eso, se bajan en total 8 pasajeros y se suben 2
24 + 8 + 2   //Solución 2: Durante todo el recorrido se suben en total 34 pasajeros


//: 3. Si tengo una deuda de 2760 y soy contratado para un trabajo por horas en donde cada hora me será pagada a 17, ¿Cuántas horas debo trabajar para pagar el total de mi deuda?

//  La solución se puede dar por regla de tres simple. Si una hora vale 17, cuántas horas representan 2750?
//  1 -> 17
//  x -> 2760

2760.0 / 17.0   //Solución: Debo trabajar 162 horas y 22 minutos (162.3529) para recibir el dinero suficiente para pagar mi deuda.



//: Playground - noun: a place where people can play

import UIKit

/*
 
 Ejercicio de Programación de Condicionales
 
 Vamos a poner en práctica lo aprendido en relación a los condicionales para determinar si una persona es Joven, Adulto, Mayor o  Veterano.
 
 CONTENIDO:
 
 Tenemos la variable edad igual a 50 y la variable state igual a un String vacío.
 
 INSTRUCCIONES:
 
 Se requiere implementar los siguientes requerimientos:
 
 Debemos utilizar los condicionales if y else para determinar lo siguiente:
 1.1 Si la edad es menor a 21 años el state es igual a Joven.
 1.2 Si la edad es mayor a 20 años y menor a 41 años el state es Adulto.
 1.3 Si la edad es mayor a 40 y menor a 61 años el state es Mayor.
 1.4 Si la edad es mayor a 60 años el state es Veterano.
 2. Finalmente hay que imprimir un mensaje de acuerdo al state. Por lo tanto haremos uso del Switch para:
 2.1 Si el case es Joven. El mensaje a imprimir es "Eres un Joven Feliz"
 2.2 Si el case es Adulto. El mensaje a imprimir es "Felicitaciones ya eres un Adulto"
 2.3 Si el case es Mayor. El mensaje a imprimir es "Eres un mayor con mucha experiencia"
	2.4 Si el case es Veterano. El mensaje a imprimir es "El mundo te admira por ser un gran Veterano"
 
 
 Happy Coding!
 
 TEN EN CUENTA:
 
 Puedes probar si todo funciona bien, cambiando la edad entre los rangos que se están manejando.
 
 */

var age = 50
var state = ""

if age < 21 {
    state = "Joven"
}else if age < 41 {
    state = "Adulto"
}else if age < 61{
    state = "Mayor"
}else{
    state = "Veterano"
}


switch (state) {
case "Joven":
    print("Eres un Joven Feliz")
case "Adulto":
    print("Felicitaciones ya eres un Adulto")
case "Mayor":
    print("Eres un mayor con mucha experiencia")
default:
    print("El mundo te admira por ser un gran Veterano")
}

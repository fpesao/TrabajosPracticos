//: Playground - noun: a place where people can play

import UIKit

/*
 Ejercicio de Codificación de Arrays y Dictionaries.
 
 Vamos a poner en práctica lo aprendido en relación a los Arrays y diccionarios en el manejo de un listado de estudiantes.
 
 CONTENIDO:
 
 Tenemos el siguiente listado de Estudiantes:
 
 1. Pedro Platon, matricula # 0230
 2. Maria Mena, matricula # 0232
 3. Kim Jackson, matricula # 0233
 
 INSTRUCCIONES:
 
 Se requiere implementar los siguientes requerimientos:
 
 Declarar un array que contenga los estudiantes en el orden dado.
 Declarar un diccionario donde su key es el número de matrícula y su value es el nombre del estudiante.
 Imprimir el número de elementos que tiene nuestro array.
 Necesitamos ingresar el estudiante Julian Pachon, matrícula # 234, tanto en el array como en el diccionario.
 Actualizar el nombre de Maria Mena por Maria Ruiz.
 Se requiere imprimir un subconjunto de nuestro array que no contenga a Pedro Platon.
 
 Happy Coding!

*/

var studentsArray = ["Pedro Platon", "Maria Mena", "Kim Jackson"]
var studentsDictionary = [0230: "Pedro Platon", 0232: "Maria Mena", 0233: "Kim Jackson"]
print("Numero de elementos de mi arrya es:", studentsArray.count)
studentsArray.append("Julian Pachon")
studentsDictionary[234] = "Julian Pachon"
studentsArray[1] = "Maria Ruiz"
studentsDictionary.updateValue("Maria Ruiz", forKey: 0232)
print(studentsArray.dropFirst())

//: Playground - noun: a place where people can play

import UIKit

/*
 Ejercicio de Programación de iteraciones.
 
 Vamos a poner en práctica lo aprendido en relación a las iteraciones para mostrar las tablas de multiplicar del uno al diez.
 
 CONTENIDO:
 
 Haciendo uso de las iteraciones se nos pide realizar un algoritmo que nos permita mostrar las tablas de multiplicar del uno al diez.
 
 
 INSTRUCCIONES:
 
 El formato en el que se debe mostrar las tablas de multiplicar es el siguiente:
 
 -----Tabla 1-----
 1 * 1 = 1
 1 * 2 = 2
 1 * 3 = 3
 1 * 4 = 4
 1 * 5 = 5
 1 * 6 = 6
 1 * 7 = 7
 1 * 8 = 8
 1 * 9 = 9
 1 * 10 = 10
 -----Tabla 2-----
 2 * 1 = 2
 2 * 2 = 4
 2 * 3 = 6
 2 * 4 = 8
 2 * 5 = 10
 2 * 6 = 12
 2 * 7 = 14
 2 * 8 = 16
 2 * 9 = 18
 2 * 10 = 20
 
 Happy Coding!
 
 TEN EN CUENTA:
 
 1. Lo puedes realizar con el ciclo while y debes tener dos índices uno para el número de la tabla y otro para controlar la iteración hasta 10.
 2. Debes hacer uso de dos ciclos repetitivos y el segundo debe estar anidado en el primero.
 3. Para poder imprimir con el formato que se nos pide se debe utilizar una estructura como está: print("\(i) * \(j) = \(i*j)"), donde i y j son los índices.
*/

var i = 1

while i <= 10 {
    var j = 1
    print("-----Tabla \(i)-----")
    while j <= 10 {
        print("\(i) * \(j) = \(i*j)")
        j = j + 1
    }
    
    i = i + 1
}

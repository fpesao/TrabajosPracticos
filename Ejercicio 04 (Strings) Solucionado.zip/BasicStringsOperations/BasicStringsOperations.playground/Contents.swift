//: Playground - noun: a place where people can play

import UIKit


var result : String

let myName = "Ihonahan"
let myAge = 38
let year = 1978
let monthSpanish = "marzo"
let monthEnglish = "march"
let day = 29
let professionSpanish = "Líder técnico de iOS"
let professionEnglish = "Technical Leader for iOS"

let spanish = "Hola, playground! Soy \(myName), nací el \(day) de \(monthSpanish) de \(year) y tengo \(myAge) años. Soy \(professionSpanish) y me encanta Swift 3!"
let english = "Hello, playground! My name is \(myName), I was born on \(monthEnglish) the \(day)th, \(year) and I'm \(myAge) years old. I'm \(professionEnglish) and I Love Swift 3!"

var inSpanish = false

result = inSpanish ? spanish : english

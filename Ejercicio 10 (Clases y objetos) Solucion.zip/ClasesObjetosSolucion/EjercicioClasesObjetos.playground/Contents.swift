//: Playground - noun: a place where people can play

import UIKit

/*

 Ejercicio de Programación de Clases y Objetos
 
 Vamos a poner en práctica lo aprendido en relación a Clases y Objetos.
 
 CONTENIDO:
 
 Vamos a crear la clase Person.
 
 INSTRUCCIONES:
 
 Se requiere cumplir con los siguientes requerimientos:
 
 Declarar los atributos name, lastName de tipo String, age de Int y mood (estado animico) de tipo Bool.
 Realizar el inicializador designado y uno de conveniencia que no recibe parámetros donde el valor mood por defecto será true..
 Hacer el método happy que lo que hace es poner la propiedad mood en true y imprimir el mensaje name lastName está Feliz. Es decir, si name es Juan y lastName es Portillo entonces el mensaje es: Juan Portillo está feliz.
 Hacer el método sad que lo que hace es poner la propiedad mood en false y imprimir el mensaje name lastName está triste. Es decir, si name es Juan y lastName es Portillo entonces el mensaje es: Juan Portillo está triste.
 Crear el objeto pedroPerson con el name Pedro, lastName Jackson, age 15 y mood en false.
 Crear el objeto luisaPerson usando el inicializador por conveniencia.
 Invocar el método happy al objeto pedroPerson.
 
 Happy Coding!
 
 TEN EN CUENTA:
 
 Para imprimir el mensaje debes utilizar algo como esto: print("\(name!) \(lastName!) está feliz")
 
*/
 
class Person {
    
    var name: String?
    var lastName: String?
    var age: Int?
    var mood: Bool?
    
    //Designated Initializer
    init(name: String, lastName: String, age: Int, mood: Bool) {
        self.name = name
        self.lastName = lastName
        self.age = age
        self.mood = mood
    }

    //Convenience Initializer
    convenience init() {
        self.init(name: "", lastName: "", age: 0, mood: true)
    }
    
    func happy() {
        mood = true
        print("\(name!) \(lastName!) está feliz")
    }
    
    func sad() {
        mood = false
        print("\(name!) \(lastName!) está triste")
    }

    
}

var pedroPerson = Person(name: "Pedro", lastName: "Jackson", age: 15, mood: false)
var luisaPerson = Person()
pedroPerson.happy()


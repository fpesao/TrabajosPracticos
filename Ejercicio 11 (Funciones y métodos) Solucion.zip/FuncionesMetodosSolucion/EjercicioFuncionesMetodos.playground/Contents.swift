//: Playground - noun: a place where people can play

import UIKit

/*

 Vamos a poner en práctica lo aprendido en relación a Funciones y Métodos.
 
 CONTENIDO:
 
 Vamos a crear la clase Account y poner en práctica lo aprendido con funciones y métodos.
 
 INSTRUCCIONES:
 
 Se requiere cumplir con los siguientes requerimientos:
 
 1. Crear la clase Account.
 2. La clase Account tiene las propiedades: names de tipo String, accountNumber de tipo Int, accountBalace de tipo Double.
 3. Se debe hacer los métodos:
 3.0 Inicializador designado. El inicializador designado es aquel que inicia todas las propiedades.
 3.1 currentBalance. Este se encarga de mostrar el mensaje: print("\(names!) Su saldo actual es de $", accountBalance!)
 3.2 consignMoney (consignación de dinero) que recibe como parámetro la cantidad de dinero que va ahorrar. El parámetro recibido se le suma al valor que hay en accountBalance y debe invocar el método accountBalance().
 3.3 withdrawal (retiro de dinero) que recibe como parámetro la cantidad de dinero que va a retirar y debe retornar un valor booleano. El parámetro recibido se le resta al valor que hay en accountBalance siempre y cuando este sea menor, de lo contrario se debe mostrar el mensaje "No hay fondos suficientes." y se retorna false. En caso de poder hacer la transacción, se debe mostrar el saldo con el que queda la cuenta luego del retiro y se retorna true.
 3.4 moneyTransfer (transferencia entre cuentas). Este no será un método de instancia y debe ser final. moneyTransfer recibe dos objetos de tipo Account y el valor a transferir que es de tipo Double y retorna un valor booleano. Lo que debe hacer el método es hacer una transferencia entre la primera cuenta y la segunda. Si es posible realizarla retorna true de lo contrario retorna false.
 4. Crear el número de cuenta número 10115423 asignado a Pablo Morales con un saldo de 23000.
 5. Crear el número de cuenta número 20115421 asignado a Laura Perez con un saldo de 12000.
 6. Laura Perez hace un retiro de 5000.
 7. Laura Perez le consigna 7000 ha Pablo Morales.
 8. Laura Perez hace un retiro de 3000. //Esto no lo debe permitir hacer.
 9. Pablo Morales le hace una consignación de 12000 a Laura Perez.
 
 Happy Coding!
 
 TEN EN CUENTA:
 
 Todos los métodos son de instancia. Exceptuando el de moneyTransfer. Recuerda no repetir código.


*/

class Account {
    
    var names: String?
    var accountNumber: Int?
    var accountBalance: Double?
    
    init(names: String, accountNumber: Int, accountBalance: Double) {
        self.names = names
        self.accountNumber = accountNumber
        self.accountBalance = accountBalance
    }
    
    func consignMoney(value: Double) {
        accountBalance = accountBalance! + value
        currentBalance()
    }
    
    func withdrawal(value: Double) -> Bool {
        var result = false
        if value >= accountBalance! {
            print("No hay fondos suficientes.")
        }else {
            accountBalance = accountBalance! - value
            currentBalance()
            result = true
        }
        return result
    }
    
    func currentBalance() {
        print("\(names!) Su saldo actual es de $", accountBalance!)
    }
    
    static func moneyTransfer(accountA: Account, accountB: Account, valueTransfer: Double) -> Bool {
        var result = false
        
        if accountA.withdrawal(value: valueTransfer) {
            accountB.consignMoney(value: valueTransfer)
            result = true
        }
        
        return result
    }
}

var accountPablo = Account(names: "Pablo Morales", accountNumber: 10115423, accountBalance: 23000)
var accountLaura = Account(names: "Laura Perez", accountNumber: 20115421, accountBalance: 12000)

accountLaura.withdrawal(value: 5000)
if Account.moneyTransfer(accountA: accountLaura, accountB: accountPablo, valueTransfer: 7000) {
    print("Transferencia Exitosa")
}else {
    print("No es posible realizar la Transferencia por falta de fondos")
}

accountLaura.withdrawal(value: 3000)
accountPablo.consignMoney(value: 12000)




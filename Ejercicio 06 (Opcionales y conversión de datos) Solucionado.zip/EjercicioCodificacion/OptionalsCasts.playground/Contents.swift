//: Playground - noun: a place where people can play

import UIKit

let integerValue1 = 5
let doubleValue1 = 6.47853
let floatValue1 : Float = 3.141592
let valueAsString1 = "2.7876"
let integerValue2 = 8
let doubleValue2 = 2.98576
let floatValue2 : Float = 8.856
let valueAsString2 = "3.9078"

var integerSum : Int?
var doubleSum : Double?
var integerAverage : Int?
var floatAverage : Float?


//: 1. Determinar si integerSum está vacío, y en caso afirmativo realizar la suma entera de todos los valores y asignarle el resultado a integerSum
let tempIntegerSum = integerValue1 + integerValue2 + Int(doubleValue1) + Int(doubleValue2) + Int(floatValue1) + Int(floatValue2) + Int(Double(valueAsString1)!) + Int(Double(valueAsString2)!)

integerSum = integerSum == nil ? tempIntegerSum : integerSum!


//: 2. Determinar si doubleSum está vacío, y en caso afirmativo realizar la suma real de todos los valores y asignarle el resultado a doubleSum
let tempDoubleSum = Double(integerValue1) + Double(integerValue2) + doubleValue1 + doubleValue2 + Double(floatValue1) + Double(floatValue2) + Double(valueAsString1)! + Double(valueAsString2)!

doubleSum = doubleSum == nil ? tempDoubleSum : doubleSum!


//: 3. Determinar si integerAverage está vacío, y en caso afirmativo realizar el promedio entero de todos los valores y asignarle el resultado a integerAverage
let tempIntegerAverage = integerSum! / 8

integerAverage = integerAverage == nil ? tempIntegerAverage : integerAverage!


//: 4. Determinar si floatAverage está vacío, y en caso afirmativo realizar el promedio flotante de todos los valores y asignarle el resultado a floatAverage
let tempFloatAverage = Float(doubleSum!) / Float(8.0)

floatAverage = floatAverage == nil ? tempFloatAverage : floatAverage!


//: 5. Por medio de la conversión String(Any) concatenar un String que exponga los resultados obtenidos
let result = "Los resultados son -> suma entera: " + String(integerSum!) + ". Suma real: " + String(doubleSum!) + ". Promedio entero: " + String(integerAverage!) + ". Promedio flotante: " + String(floatAverage!)

print(result)
